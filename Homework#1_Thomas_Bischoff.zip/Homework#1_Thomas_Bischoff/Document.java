/** 
 * A class that represents a text document
 */
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Document {

	public String text;
	
	/** Create a new document from the given text.
	 * Because this class is abstract, this is used only from subclasses.
	 * @param text The text of the document.
	 */
	protected Document(String text)
	{
		this.text = text;
	}
	
	/** Returns the tokens that match the regex pattern from the document 
	 * text string.
	 * @param pattern A regular expression string specifying the 
	 *   token pattern desired
	 * @return A List of tokens from the document text that match the regex 
	 *   pattern
	 */
	protected List<String> getTokens(String pattern)
	{
		ArrayList<String> tokens = new ArrayList<String>();
		Pattern tokSplitter = Pattern.compile(pattern);
		Matcher m = tokSplitter.matcher(text);
		
		while (m.find()) {
			tokens.add(m.group());
		}
		
		return tokens;
	}
	
	/** This is a helper function that returns the number of syllables
	 * in a word.  You should write this and use it in your 
	 * BasicDocument class.
     *
	 * Just use a loop to loop through the 
	 * characters in the string and write your own logic for counting 
	 * syllables.
	 * 
	 * @param word  The word to count the syllables in
	 * @return The number of syllables in the given word, according to 
	 * this rule: Each contiguous sequence of one or more vowels is a syllable, 
	 *       with the following exception: a lone "e" at the end of a word 
	 *       is not considered a syllable unless the word has no other syllables. 
	 *       You should consider y a vowel.
	 */
	protected int countSyllables(String word)
	{
		// TODO: Implement this method so that you can call it from the 
	    // getNumSyllables method in BasicDocument
		// Convert the word to be lower-case
		word = word.toLowerCase();
		// String of vowels
		String vowels = "a e i o u y";
		// Ending case of vowels
		String ending_vowels = "a i o u y";
		// Create value to represent the number of syllables
		int num_of_syllables = 0;
		// Set that last character was not a vowel
		boolean last_char_not_vowel = true;
		// Go through the word
		for(int i = 0; i < (word.length()); i++)
		{
			// Check that the current character is not at the end of the word
			if(i < (word.length() - 1))
			{
				// Check if the character is a vowel
				if((vowels.indexOf(word.charAt(i))) >= 0)
				{
					// Check that the last character was not a vowel
					if(last_char_not_vowel)
					{
						// Set last character was a vowel
						last_char_not_vowel = false;
						// Increase the number of syllables by 1
						num_of_syllables += 1;
					}
				}
				// Otherwise
				else
				{
					// Set the last character to not be a vowel
					last_char_not_vowel = true;
				}
			}
			// Otherwise
			else
			{
				// Check if the last character is an ending syllable
				if((ending_vowels.indexOf(word.charAt(i))) >= 0)
				{
					// Check that if the last value was not a vowel
					if(last_char_not_vowel)
					{
						// Increase the number of syllables by 1
						num_of_syllables += 1;
					}
				}
				// Check if the last character is an 'e'
				else if((word.charAt(i)) == 'e')
				{
					// Check the there are no other syllables
					if(num_of_syllables == 0)
					{
						// Set the number of syllables to be 1
						num_of_syllables = 1;
					}
				} 
			}
		}
		// Return the number of syllables
		return num_of_syllables;
	}
	
	/** A method for testing
	 * 
	 * @param doc The Document object to test
	 * @param syllables The expected number of syllables
	 * @param words The expected number of words
	 * @param sentences The expected number of sentences
	 * @return true if the test case passed.  False otherwise.
	 */
	public static boolean testCase(Document doc, int syllables, int words, int sentences)
	{
		System.out.println("Testing text: ");
		System.out.print(doc.getText() + "\n....");
		boolean passed = true;
		int syllFound = doc.getNumSyllables();
		int wordsFound = doc.getNumWords();
		int sentFound = doc.getNumSentences();
		// Calculate the Flesch score
		double flesch_score =getFleschScore(wordsFound, sentFound, syllFound);
		// Display the Flesch score
		System.out.println("The Flesch Score is " + flesch_score);
		if (syllFound != syllables) {
			System.out.println("\nIncorrect number of syllables.  Found " + syllFound 
					+ ", expected " + syllables);
			passed = false;
		}
		if (wordsFound != words) {
			System.out.println("\nIncorrect number of words.  Found " + wordsFound 
					+ ", expected " + words);
			passed = false;
		}
		if (sentFound != sentences) {
			System.out.println("\nIncorrect number of sentences.  Found " + sentFound 
					+ ", expected " + sentences);
			passed = false;
		}
		
		if (passed) {
			System.out.println("passed.\n");
		}
		else {
			System.out.println("FAILED.\n");
		}
		return passed;
	}
	
	
	/** Return the number of words in this document */
	public abstract int getNumWords();
	
	/** Return the number of sentences in this document */
	public abstract int getNumSentences();
	
	/** Return the number of syllables in this document */
	public abstract int getNumSyllables();
	
	/** Return the entire text of this document */
	public String getText()
	{
		return this.text;
	}
	
	/** return the Flesch readability score of this document */
	public static double getFleschScore(int words, int sentences, int syllables)
	{
	    // TODO: Implement this method.
		// Create a value for the number of words
		double double_words = (double) words;
		// Create a value for the number of sentences
		double double_sentences = (double) sentences;
		// Create a value for the number of syllables
		double double_syllables = (double) syllables;
		// Calculate the Flesch score
		double flesch_score = 206.835 - 1.015 * (double_words / double_sentences) - 84.6 * (double_syllables / double_words);
		// Return the Flesch score
		return flesch_score;
	}
	
	
	
}