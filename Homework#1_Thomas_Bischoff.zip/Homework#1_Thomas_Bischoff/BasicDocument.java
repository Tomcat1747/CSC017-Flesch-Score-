import java.util.List;

/** 
 * A naive implementation of the Document abstract class. 
 */
public class BasicDocument extends Document 
{
	/** Create a new BasicDocument object
	 * 
	 * @param text The full text of the Document.
	 */
	public BasicDocument(String text)
	{
		super(text);
	}
	
	
	/**
	 * Get the number of words in the document.
	 * A "word" is defined as a contiguous string of alphabetic characters
	 * i.e. any upper or lower case characters a-z or A-Z.  This method completely 
	 * ignores numbers when you count words, and assumes that the document does not have 
	 * any strings that combine numbers and letters. 
	 * 
	 * Check the examples in the main method below for more information.
	 * 
	 * This method should process the entire text string each time it is called.  
	 * 
	 * @return The number of words in the document.
	 */
	@Override
	public int getNumWords()
	{
		//TODO: Implement this method according to the comments above.
		// Create a variable for the number of words
		int num_of_words = 0;
		// Check if text is empty
		if(text.equals(""))
		{
			// Return the number of words
			return num_of_words;
		}
		// Check if the string has a '('
		if((text.indexOf('(')) >= 0)
		{
			// Replace the character with an empty space
			text = text.replace("(", "");
		}
		// Check if the string has a ')'
		if((text.indexOf(')')) >= 0)
		{
			// Replace the character with an empty space
			text = text.replace(")", "");
		}
		// Split the string when spaces appear
		String[] words = text.split("\\s+");
		// Go through the list of words created
		for(int i = 0; i < (words.length); i++)
		{
			// Get the current word
			String word = words[i];
			//Get the first character
			char first_char = word.charAt(0);
			// Get the ASCII value of the first character
			int ascii_value = (int) first_char;
			// Check to see if the ASCII value is for a letter
			if(((ascii_value >= 65) && (ascii_value <= 90)) || ((ascii_value >= 97) && (ascii_value <= 122)))
			{
				// Increment the number of words by 1
				num_of_words = num_of_words + 1;
			}
		}
		// Return the number of words
		return num_of_words;
	}
	
	/**
	 * Get the number of sentences in the document.
	 * Sentences are defined as contiguous strings of characters ending in an 
	 * end of sentence punctuation (. ! or ?) or the last contiguous set of 
	 * characters in the document, even if they don't end with a punctuation mark.
	 * 
	 * Check the examples in the main method below for more information.  
	 * 
	 * This method should process the entire text string each time it is called.  
	 * 
	 * @return The number of sentences in the document.
	 */
	@Override
	public int getNumSentences()
	{
	    //TODO: Implement this method.
		// Set a value for the number of sentences
		int num_of_sentences = 0;
		// Check if the string is empty;
		if(text.equals(""))
		{
			// Return the number of sentences
			return num_of_sentences;
		}
		// Split the string into a list of words
		String words[] = text.split("\\s+");
		// Go through the list of words
		for(int i = 0; i < (words.length); i++)
		{
			// Create a value to hold the word
			String word = words[i];
			// Create a value to hold the ending index of the word
			int ending_index = (word.length()) - 1;
			// Check if the string ends with a "."
			if((word.charAt(ending_index)) == '.')
			{
				// Increase the number of sentences by 1
				num_of_sentences = 1 + num_of_sentences;
			}
			// Check if the string ends with a "."
			else if((word.charAt(ending_index)) == '!')
			{
				// Increase the number of sentences by 1
				num_of_sentences = 1 + num_of_sentences;
			}
			// Check if the string ends with a '?'
			else if((word.charAt(ending_index)) == '?')
			{
				// Increase the number of sentences by 1
				num_of_sentences = 1 + num_of_sentences;
			}
			// Check if the string ends with a ':'
			else if((word.charAt(ending_index)) == ':')
			{
				// Increase the number of sentences by 1
				num_of_sentences = 1 + num_of_sentences;
			}
		}
		// Create a value to hold the last word in the string
		String last_word = words[words.length - 1];
		// Check that the last word does not have punctuation
		if((last_word.indexOf('.') < 0) && (last_word.indexOf('?') < 0) && (last_word.indexOf('!') < 0))
		{
			// Increase the num_of_sentences by 1
			num_of_sentences += 1;
		}
		// Return the number of sentences
		return num_of_sentences;
	}
	
	/**
	 * Get the total number of syllables in the document (the stored text). 
	 * To count the number of syllables in a word, it uses the following rules:
	 *       Each contiguous sequence of one or more vowels is a syllable, 
	 *       with the following exception: a lone "e" at the end of a word 
	 *       is not considered a syllable unless the word has no other syllables. 
	 *       You should consider y a vowel.
	 *       
	 * Check the examples in the main method below for more information.  
	 * 
	 * This method should process the entire text string each time it is called.  
	 * 
	 * @return The number of syllables in the document.
	 */
	@Override
	public int getNumSyllables()
	{
	    //TODO: Implement this method. And note that there is no need to use a regular
		// expression for the syllable counting.  We recommend you implement 
		// the helper function countSyllables in Document.java using a loop, 
		// and then call it here on each word.
		// Create a value to represent the number of syllables
		int num_of_syllables = 0;
		String new_text = text;
		// Check if the string is empty
		if(new_text.equals(""))
		{
			// Return the number of syllables
			return num_of_syllables;
		}
		// Check if the string has a '.'
		if((new_text.indexOf('.')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace(".", "");
		}
		// Check if the string has a '?'
		if((new_text.indexOf('?')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace("?", "");
		}
		// Check if the string has a '!'
		if((new_text.indexOf('!')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace("!", "");
		}
		// Check if the string has a ','
		if((new_text.indexOf(',')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace(",", "");
		}
		// Check if the string has a ':'
		if((new_text.indexOf(':')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace(":", "");
		}
		// Check if the string has a '('
		if((new_text.indexOf('(')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace("(", "");
		}
		// Check if the string has a '.'
		if((new_text.indexOf(')')) >= 0)
		{
			// Replace the character with an empty space
			new_text = new_text.replace(")", "");
		}
		// Split the sentence at the occurrence of a " "
		String[] words = new_text.split("\\s+");
		// Go through the array of words
		for(int i = 0; i < (words.length); i++)
		{
			// Create a value to count the number of syllables
			int syllables = countSyllables(words[i]);
			// Increase the total number of syllables
			num_of_syllables = syllables + num_of_syllables;
		}
		// Return the number of syllables
		return num_of_syllables;
	}
	
	
	/* The main method for testing this class. 
	 * You are encouraged to add your own tests.  */
	public static void main(String[] args)
	{
		/* Each of the test cases below uses the method testCase.  The first 
		 * argument to testCase is a Document object, created with the string shown.
		 * The next three arguments are the number of syllables, words and sentences 
		 * in the string, respectively.  You can use these examples to help clarify 
		 * your understanding of how to count syllables, words, and sentences.
		 */
		testCase(new BasicDocument("This is a test.  How many???  "
		        + "Senteeeeeeeeeences are here... there should be 5!  Right?"),
				16, 13, 5);
		testCase(new BasicDocument(""), 0, 0, 0);
		testCase(new BasicDocument("sentence, with, lots, of, commas.!  "
		        + "(And some poaren)).  The output is: 7.5."), 15, 11, 4);
		testCase(new BasicDocument("many???  Senteeeeeeeeeences are"), 6, 3, 2);
		testCase(new BasicDocument("Here is a series of test sentences. Your program should "
				+ "find 3 sentences, 33 words, and 49 syllables. Not every word will have "
				+ "the correct amount of syllables (example, for example), "
				+ "but most of them will."), 49, 33, 3);
		testCase(new BasicDocument("Segue"), 2, 1, 1);
		testCase(new BasicDocument("Sentence"), 2, 1, 1);
		testCase(new BasicDocument("Sentences?!"), 3, 1, 1);
		testCase(new BasicDocument("Lorem ipsum dolor sit amet, qui ex choro quodsi moderatius, nam dolores explicari forensibus ad."),
		         32, 15, 1);
	}
}